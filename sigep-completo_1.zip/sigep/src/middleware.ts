import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { authService } from '@/lib/services/auth.service';

const PUBLIC_PATHS = ['/auth/login', '/auth/first-access', '/api/auth/login'];
const RT_ONLY_PATHS = ['/employees', '/approvals', '/audit', '/settings', '/api/employees', '/api/schedule/generate', '/api/schedule/publish'];

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Permitir paths públicos
  if (PUBLIC_PATHS.some((p) => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  // Verificar token
  const token = request.cookies.get('sigep_token')?.value;
  if (!token) {
    const loginUrl = new URL('/auth/login', request.url);
    loginUrl.searchParams.set('redirect', pathname);
    return NextResponse.redirect(loginUrl);
  }

  const payload = authService.verifyToken(token);
  if (!payload) {
    const response = NextResponse.redirect(new URL('/auth/login', request.url));
    response.cookies.delete('sigep_token');
    return response;
  }

  // Verificar acesso restrito ao RT
  if (RT_ONLY_PATHS.some((p) => pathname.startsWith(p)) && payload.role !== 'RT') {
    return NextResponse.redirect(new URL('/dashboard', request.url));
  }

  // Forçar troca de senha no primeiro acesso
  if (pathname !== '/auth/first-access') {
    const cookieFirstAccess = request.cookies.get('sigep_first_access')?.value;
    if (cookieFirstAccess === 'true') {
      return NextResponse.redirect(new URL('/auth/first-access', request.url));
    }
  }

  // Adicionar claims ao header para uso nos Server Components
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set('x-user-id', payload.sub);
  requestHeaders.set('x-user-role', payload.role);

  return NextResponse.next({ request: { headers: requestHeaders } });
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|icons|manifest.json|sw.js|workbox-.*|api/push).*)',
  ],
};
